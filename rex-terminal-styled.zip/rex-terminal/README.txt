REX Terminal - Visual Edition
Requires Python 3. No additional packages.
Install or update and launch:
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
Future launches: rex
Terminal only; no browser.
Display: green/black theme, animated activity indicator, live progress,
colored result rows and final timing summary.
The animation runs separately and does not throttle network requests.
Request settings match the supplied script:
MAX_REQUESTS = 10000
MAX_WORKERS = 50
REQUEST_TIMEOUT = 15
Request execution and timing behavior are unchanged.
