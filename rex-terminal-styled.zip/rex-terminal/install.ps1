$ErrorActionPreference = 'Stop'
if (-not (Get-Command py -ErrorAction SilentlyContinue) -and -not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw 'Install Python 3, then run install.ps1 again.'
}
$target = Join-Path $env:LOCALAPPDATA 'REX'
New-Item -ItemType Directory -Path $target -Force | Out-Null
foreach ($name in @('rex.py','rex.cmd','uninstall.ps1')) {
    Copy-Item (Join-Path $PSScriptRoot $name) (Join-Path $target $name) -Force
}
$paths = @([Environment]::GetEnvironmentVariable('Path', 'User') -split ';' | Where-Object { $_ })
if ($paths -notcontains $target) {
    [Environment]::SetEnvironmentVariable('Path', (($paths + $target) -join ';'), 'User')
}
if (($env:Path -split ';') -notcontains $target) { $env:Path += ";$target" }
Write-Host 'REX installed. Starting terminal console...' -ForegroundColor Green
& (Join-Path $target 'rex.cmd')
