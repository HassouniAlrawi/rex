@echo off
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0rex.py" %*
    exit /b
)
python "%~dp0rex.py" %*
