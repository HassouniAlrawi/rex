import os
import sys
import shutil
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError

# Maximum number accepted by the input field.
MAX_REQUESTS = 10000
# Maximum simultaneous connections; independent of the total request count.
MAX_WORKERS = 50
REQUEST_TIMEOUT = 15

GREEN = '\033[92m'
DIM = '\033[32m'
RED = '\033[91m'
CYAN = '\033[96m'
RESET = '\033[0m'


def prepare_console():
    if os.name == 'nt':
        import ctypes
        handle = ctypes.windll.kernel32.GetStdHandle(-11)
        mode = ctypes.c_ulong()
        if ctypes.windll.kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            ctypes.windll.kernel32.SetConsoleMode(handle, mode.value | 4)
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    print('\033[40m\033[2J\033[H', end='')


UI_LOCK = threading.Lock()
LIVE = None


def rule():
    width = min(72, max(32, shutil.get_terminal_size((80, 24)).columns - 4))
    print(DIM + '  ' + '━' * width + RESET)


def title():
    rule()
    print(GREEN + '\n  R E X   ◈   N E T W O R K   C O N S O L E' + RESET)
    print(DIM + '  CONNECTION ENGINE   /   TERMINAL EDITION   /   V4.0\n' + RESET)
    rule()


class LiveDisplay:
    def __init__(self, count):
        self.count = count
        self.completed = self.success = self.failed = 0
        self.started = time.perf_counter()
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self.animate, daemon=True)

    def animate(self):
        frames = ('◐', '◓', '◑', '◒')
        index = 0
        while not self.stop_event.is_set():
            with UI_LOCK:
                filled = int(18 * self.completed / self.count)
                bar = '█' * filled + '░' * (18 - filled)
                elapsed = time.perf_counter() - self.started
                print('\r\033[2K' + GREEN + f'  {frames[index % 4]} [{bar}] '
                      + f'{self.completed}/{self.count}  '
                      + CYAN + f'{elapsed:.1f}s' + RESET, end='', flush=True)
            index += 1
            self.stop_event.wait(0.12)

    def start(self):
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        self.thread.join()
        with UI_LOCK:
            print('\r\033[2K', end='', flush=True)


def request_once(number, url, gate):
    gate.wait()
    started = time.perf_counter()
    status = None
    error = ''
    try:
        with urlopen(Request(url, headers={'User-Agent': 'REX/3.0'}), timeout=REQUEST_TIMEOUT) as response:
            status = response.status
    except HTTPError as exc:
        status = exc.code
        exc.close()
    except Exception as exc:
        error = str(exc).replace('\n', ' ').replace('\r', ' ')
    return {'number': number, 'status': status,
            'ok': status is not None and 200 <= status < 400,
            'ms': (time.perf_counter() - started) * 1000, 'error': error}


def execute(url, count, on_result):
    results = []
    gate = threading.Event()
    pool = ThreadPoolExecutor(max_workers=min(count, MAX_WORKERS))
    started = time.perf_counter()
    stopped = False
    try:
        futures = [pool.submit(request_once, number, url, gate) for number in range(1, count + 1)]
        gate.set()
        for future in as_completed(futures):
            item = future.result()
            results.append(item)
            on_result(item, len(results), count)
    except KeyboardInterrupt:
        stopped = True
        for future in locals().get('futures', []):
            future.cancel()
        print(RED + '\n  Stopping; active connections are finishing...' + RESET)
    finally:
        gate.set()
        pool.shutdown(wait=True, cancel_futures=True)
    return results, time.perf_counter() - started, stopped


def show_result(item, completed, count):
    with UI_LOCK:
        print('\r\033[2K', end='')
        color = GREEN if item['ok'] else RED
        symbol = '✓' if item['ok'] else '✕'
        print(color + f"  {symbol} {item['number']:05}  "
              + f"{'SUCCESS' if item['ok'] else 'FAILED ':<8}  "
              + DIM + 'HTTP ' + color + f"{str(item['status'] or 'ERR'):<5}  "
              + CYAN + f"{item['ms']:9.1f} ms" + RESET, flush=True)
        if item['error']:
            print(DIM + '           ' + item['error'][:90] + RESET)
        if LIVE is not None:
            LIVE.completed = completed
            LIVE.success += int(item['ok'])
            LIVE.failed += int(not item['ok'])


def run():
    global LIVE
    prepare_console()
    title()
    print(CYAN + '\n  01  CONNECTION SETUP' + RESET)
    while True:
        url = input(GREEN + '\n  ◈ Target URL > ' + RESET).strip()
        try:
            parts = urlsplit(url)
            if parts.scheme in ('http', 'https') and parts.hostname:
                break
        except ValueError:
            pass
        print(RED + '  ✕ Enter a valid http:// or https:// URL.' + RESET)
    while True:
        try:
            count = int(input(GREEN + '  ◈ Number of requests > ' + RESET))
            if 1 <= count <= MAX_REQUESTS:
                break
        except ValueError:
            pass
        print(RED + '  ✕ Invalid request count. Enter another number.' + RESET)
    print()
    rule()
    print(CYAN + '\n  02  LIVE ACTIVITY' + RESET)
    print(DIM + f'  REQUESTS {count}   /   PARALLEL {min(count, MAX_WORKERS)}' + RESET)
    print(DIM + '\n  ID        RESULT     STATUS       RESPONSE TIME\n' + RESET)
    LIVE = LiveDisplay(count)
    LIVE.start()
    try:
        results, duration, stopped = execute(url, count, show_result)
    finally:
        LIVE.stop()
        LIVE = None
    total = len(results)
    success = sum(item['ok'] for item in results)
    print()
    rule()
    print(CYAN + '\n  03  SESSION REPORT' + RESET)
    print((RED if stopped else GREEN) + ('  ◈ STOPPED' if stopped else '  ✓ COMPLETE') + RESET)
    print(GREEN + f'\n  COMPLETED     {total:<10} SUCCESS     {success}' + RESET)
    print(RED + f'  FAILED        {total-success}' + RESET)
    if results:
        times = [item['ms'] for item in results]
        print(CYAN + f'\n  AVERAGE       {sum(times)/total:.1f} ms' + RESET)
        print(CYAN + f'  FASTEST       {min(times):.1f} ms' + RESET)
        print(CYAN + f'  SLOWEST       {max(times):.1f} ms' + RESET)
    print(GREEN + f'  DURATION      {duration:.2f} seconds\n' + RESET)
    rule()
    print()


if __name__ == '__main__':
    try:
        run()
    except (KeyboardInterrupt, EOFError):
        print('\nREX closed.')
    finally:
        print(RESET, end='')
