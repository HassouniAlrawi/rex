$target = Join-Path $env:LOCALAPPDATA 'REX'
$paths = @([Environment]::GetEnvironmentVariable('Path', 'User') -split ';' | Where-Object { $_ -and $_ -ne $target })
[Environment]::SetEnvironmentVariable('Path', ($paths -join ';'), 'User')
$env:Path = (($env:Path -split ';' | Where-Object { $_ -ne $target }) -join ';')
Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'REX removed.'
